# text_extraction_project/__init__.py
