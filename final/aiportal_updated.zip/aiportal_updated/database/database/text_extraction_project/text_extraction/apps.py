from django.apps import AppConfig

class TextExtractionConfig(AppConfig):
    name = 'text_extraction'
